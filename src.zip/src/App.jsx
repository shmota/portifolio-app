import PageHolder from './components/PageHolder/PageHolder'
import './App.scss'
import Home from './pages/Home/Home'
import AboutMe from './pages/AboutMe/AboutMe'
import Abilities from './pages/Abilities/Abilities'
import Projects from './pages/Projects/Projects'
import SidebarNav from './components/SideBarNav/SideBarNav'
import Threads from './components/BackgroundBit/Threads'
import { useState, useEffect, useRef } from 'react'

function App() {

  const [activeIndex, setActiveIndex] = useState(0);
  const sectionsRef = useRef([]);
  const [sections, setSections] = useState([]);

  useEffect(() => {
    if (sectionsRef.current.length === 0) return;

    setSections(
      sectionsRef.current.map((el) => ({
        id: el.id,
        label: el.dataset.label
      }))
    );

    const handleScroll = () => {
      const center = window.innerHeight / 2;

      const distances = sectionsRef.current.map((el, i) => {
        if (!el) return { index: i, distance: Infinity };

        const rect = el.getBoundingClientRect();
        const elCenter = rect.top + rect.height / 2;

        return {
          index: i,
          distance: Math.abs(center - elCenter)
        };
      });

      const closest = distances.sort((a, b) => a.distance - b.distance)[0];

      if (closest.index !== activeIndex) {
        setActiveIndex(closest.index);
      }
    };

    // roda uma vez ao montar
    handleScroll();

    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [activeIndex]);

  const pages = [
    { id: 'home', label: 'Inicio', labelIsTitle: false, component: <Home /> },
    { id: 'about-me', label: 'Sobre mim', labelIsTitle: false, component: <AboutMe /> },
    { id: 'abilities', label: 'Habilidades', labelIsTitle: true, component: <Abilities /> },
    { id: 'projects', label: 'Projetos', labelIsTitle: true, component: <Projects /> }
  ];

  return (
    <>
      <div style={{
        position: 'fixed',
        inset: 0,
        zIndex: -1
      }}>
        <Threads
          color={[0.1843137254901961, 0.19607843137254902, 0.2980392156862745]}
          amplitude={1}
          distance={0}
          enableMouseInteraction={false}
        />
      </div>

      <div className="App">
        <SidebarNav sections={sections} activeIndex={activeIndex} />

        {pages.map((page, index) => (
          <PageHolder
            key={page.id}
            sectionName={page.id}
            label={page.label}
            innerRef={(el) => (sectionsRef.current[index] = el)}
            labelIsTitle = {page.labelIsTitle}
          >
            {page.component}
          </PageHolder>
        ))}
      </div>
    </>
  )
}

export default App